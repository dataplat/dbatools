﻿<#	
	.NOTES
	===========================================================================
	 Created with: 	SAPIEN Technologies, Inc., PowerShell Studio 2017 v5.4.145
	 Created on:   	21.10.2017 14:42
	 Created by:   	Friedrich Weinmann
	 Organization: 	Infernal Associates Ltd.
	 Filename:     	offloadTEPP.ps1
	===========================================================================
	.DESCRIPTION
		A description of the file.
#>

